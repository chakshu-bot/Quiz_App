import 'package:flutter/material.dart';
import 'fourth.dart';
class Question {
  final String question;
  final String correctAnswer;
  final List<dynamic> wrongAnswer;
  Question({required this.question, required this.correctAnswer, required this.wrongAnswer});
}
class QuestionScreen extends StatefulWidget {
  QuestionScreen({super.key, required this.qquestions});

  
  final List<Question> qquestions;
  
  @override
  State<QuestionScreen> createState() => _QuestionScreenState();
}
int current_index =0;
Color border_color = Colors.black;
Color border_color1 = Colors.black;
int points = 0;

class _QuestionScreenState extends State<QuestionScreen> {
  void function_Activated(){
  setState((){
    border_color = Colors.black;
    border_color1 = Colors.black;
    if(current_index < widget.qquestions.length - 1){
   current_index++;
   }
  else{
    current_index = 0;
    Navigator.push(
    context,
    MaterialPageRoute(builder: (context) => const EndScreen()),
  );

  }
  });
}
  @override
  Widget build(BuildContext context) {
    final final_ques = widget.qquestions[current_index];
    final final_questions=[
    Question(question: (final_ques.question), correctAnswer: (final_ques.correctAnswer), wrongAnswer: (final_ques.wrongAnswer) ),
    ];
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Color(0xFFD48BA0),
        title: Text('Question: ${current_index + 1}'),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
             colors: [Color(0xFFFFC1CC), Color(0xFFF8E2CF), Color(0xFFB6D7E5), Color(0xFFD1C4E9)],
             stops: [0.0, 0.33, 0.66, 1.0],
             center: Alignment.center,
             radius: 0.8,
              )
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                   margin: EdgeInsets.all(5.0),
                   decoration: BoxDecoration(
                    color: Color(0xFFF8E2CF), 
                    borderRadius: BorderRadius.circular(12.0),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black12,
                      blurRadius: 8.0,
                      offset: Offset(2, 2),
                    ),
                  ],
                  ) ,
                  child: Padding(
                    padding: const EdgeInsets.all(3.0),
                    child: Text((final_ques.question).replaceAll(('&quot;'),'"').replaceAll(('&#039;'), "'").replaceAll('&eacute;','é').replaceAll('&amp;', '&'), softWrap: true ,style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: Color(0xFF4A4A4A)),
                    ),
                  )
                  ),
              ),
              Padding(
                padding: const EdgeInsets.all(3.0),
                child: Container(
                  margin: EdgeInsets.all(5.0),                   
                  decoration: BoxDecoration(                    
                    border: Border.all(color: border_color, width: 3),
                  ),
                  width: double.infinity, 
                  child: TextButton(
                    child: Text((final_ques.correctAnswer).replaceAll(('&quot;'),'"').replaceAll(('&#039;'), "'").replaceAll('&eacute;','é').replaceAll('&amp;', '&'),softWrap: true, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Color(0xFF5D5D5D)),
                    ),
                    onPressed: (){
                      setState(() {
                        if(border_color == Colors.black && border_color1 == Colors.black){
                          points++;
                        }
                      border_color = Colors.green;
                      
                      });
                    },
                    )
                  ),
              ),
                ...final_ques.wrongAnswer.map((answer) => Padding(
                padding: const EdgeInsets.all(3.0),
                child: Container(
                  margin: EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    border: Border.all(color: border_color1, width: 3),
                  ),
                  width: double.infinity,
                  child: TextButton(
                    child: Text(
                      answer.replaceAll(('&quot;'),'"').replaceAll(('&#039;'), "'").replaceAll('&eacute;','é').replaceAll('&amp;', '&'),
                      softWrap: true,
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Color(0xFF5D5D5D)),
                    ),
                    onPressed: (){
                      setState(() {
                       border_color1 = Colors.red;
                       });
                    },
                  ),
                ),
              )).toList(),
              FloatingActionButton(
                child: Icon(Icons.arrow_right,
                size: 30,
                 color: Color(0xFFFFC1CC),
                 shadows: [
                  Shadow(
                     blurRadius: 10.0,
                     color: Color(0xFF87CEEB), // Accent color for shadow
                     offset: Offset(2, 2),
                     ),
                    ],
                ),
                onPressed: (){
                  if(border_color != Colors.black || border_color1 != Colors.black)
                  function_Activated();
                  else{}
                },
              ),
            ]),
        ),
      ),
    );
  }
}
