import 'package:flutter/material.dart';

class ScoreScreen extends StatelessWidget {
  final List storageScore;

  const ScoreScreen({super.key, required this.storageScore});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        title: Text('All Previous Scores', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),),
        backgroundColor: Color(0xFF483D8B),
      ),
      body: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: RadialGradient(
            colors: [Color(0xFFE6E6FA), Color(0xFFFFDAD9), Color(0xFF98FB98),Color(0xFF87CEEB)],
            stops: [0.0,0.33,0.66,1.0],
          ),
        ),
        child: ListView.builder(
          itemCount: storageScore.length,
          itemBuilder: (context, index) {
            return ListTile(
              title: Text(storageScore[index], style: TextStyle(fontWeight: FontWeight.bold, fontSize:20), ),
            );
          },
        ),
      ),
    );
  }
}

