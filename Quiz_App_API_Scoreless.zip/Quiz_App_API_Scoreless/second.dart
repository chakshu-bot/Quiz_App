import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as https;

import 'third.dart';

int number_of_questions=0;
int category_number = 0;
String difficulty_level = '';
String question_type = '';

class Second extends StatelessWidget {
  const Second({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp();
  }
}
class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key});
  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  void getquestions () async {
    final uri = Uri.https("opentdb.com","/api.php",{"amount": "$number_of_questions", "category": "$category_number", "difficulty": "$difficulty_level", "type": "$question_type"});
    final result = await https.get(uri);
    final body = jsonDecode(result.body);
    final storage_data = body['results'] as List;
    List<Question> quiz_questions = [];
    for(int i=0;i < storage_data.length; i++){
      final quiz_question = storage_data [i];
      Question question_all = Question(
        question: quiz_question['question'],
        correctAnswer: quiz_question['correct_answer'],
        wrongAnswer: quiz_question['incorrect_answers']
      );
      quiz_questions.add(question_all);
      Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => QuestionScreen(qquestions: quiz_questions,)),
      );
    }
  }
  String selectedOption = 'Any Category';
  String selectedOption1 = 'Any Difficulty';
  String selectedOption2 = 'Any Type';

  Map<String, int> options = {
    'Any Category': 0,
    'General Knowledge': 9,
    'Entertainment: Books': 10,
    'Entertainment: Film': 11,
    'Entertainment: Music': 12,
    'Entertainment: Musicals & Theaters': 13,
    'Entertainment: Television': 14,
    'Entertainment: Video Games': 15,
    'Entertainment: Board Games': 16,
    'Science & Nature': 17,
    'Science: Computers': 18,
    'Science: Mathematics': 19,
    'Mythology': 20,
    'Sports': 21,
    'Geography': 22,
    'History': 23,
    'Politics': 24,
    'Art': 25,
    'Celebrities': 26,
    'Animals': 27,
    'Vehicles': 28,
    'Entertainment: Comics': 29,
    'Science: Gadgets': 30,
    'Entertainment: Japnese Anime & Manga': 31,
    'Entertainment: Cartoon & Animations': 32,
  };

  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF483D8B),
        elevation: 0,
        title: Text('Quiz Settings', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            colors: [Color(0xFFE6E6FA), Color(0xFFFFDAD9), Color(0xFF98FB98),Color(0xFF87CEEB)],
            stops: [0.0,0.33,0.66,1.0],
          )
        ),
        child: Column(
          children: [
              Padding(
                padding: const EdgeInsets.all(3.0),
                child: Text('Enter the number of questions', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20,color: Color(0xFF2F4F4F),),),
              ),
                 TextField(
                 onChanged: (value ){
                  number_of_questions = int.parse(value);
                 },
                 ),
      Padding(
        padding: const EdgeInsets.all(8.0),
        child: Text('Select Category',style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20 ,color: Color(0xFF2F4F4F),),),
      ),
      DropdownButton<String>(
        value: selectedOption,
        isExpanded: true,
        onChanged: (value){
          setState(() {
          selectedOption = value!;
          category_number = options[value]!;
           });
        },
        items: <String>['Any Category', 'General Knowledge', 'Entertainment: Books', 'Entertainment: Film', 'Entertainment: Music', 'Entertainment: Musicals & Theaters', 'Entertainment: Television', 'Entertainment: Video Games', 'Entertainment: Board Games', 'Science & Nature', 'Science: Computers', 'Science: Mathematics', 'Mythology', 'Sports', 'Geography', 'History', 'Politics','Art', 'Celebrities', 'Animals', 'Vehicles', 'Entertainment: Comics', 'Science: Gadgets', 'Entertainment: Japnese Anime & Manga', 'Entertainment: Cartoon & Animations']
              .map<DropdownMenuItem<String>>((String value) {
            return DropdownMenuItem<String>(
              value: value,
              child: Text(value),
            );
          }).toList(),
      ),
        Padding(
          padding: const EdgeInsets.all(6.0),
          child: Text('Select Difficulty', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20,color: Color(0xFF2F4F4F),),),
        ),
        DropdownButton<String>(
        value: selectedOption1,
        isExpanded: true,
        onChanged: (value){
          setState(() {
          selectedOption1 = value!;
          if(selectedOption1 == "Any Difficulty"){
              difficulty_level = 0.toString();
          }
          else{
            difficulty_level = value;
          }
           });
        },
        items: <String>['Any Difficulty','easy', 'medium', 'hard']
              .map<DropdownMenuItem<String>>((String value) {
            return DropdownMenuItem<String>(
              value: value,
              child: Text(value),
            );
          }).toList(),
      ),
      Padding(
        padding: const EdgeInsets.all(6.0),
        child: Text('Select Type', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20,color: Color(0xFF2F4F4F),),),
      ),
      DropdownButton<String>(
        value: selectedOption2,
        isExpanded: true ,
        onChanged: (value){
          setState(() {
          selectedOption2 = value!;
          if(selectedOption2 == "Any Type"){
            question_type = 0.toString() ;
          }
          else if(selectedOption2 == "Multiple Choice"){
            question_type = "multiple";
          }
          else{
            question_type = "boolean";
          }
           });
        },
        items: <String>['Any Type', 'Multiple Choice', 'True/False']
              .map<DropdownMenuItem<String>>((String value) {
            return DropdownMenuItem<String>(
              value: value,
              child: Text(value),
            );
          }).toList(),
      ),
      Padding(
        padding: const EdgeInsets.all(6.0),
        child: FloatingActionButton(
           backgroundColor: Color(0xFF483D8B),
           child: Icon(Icons.check),
           onPressed: (){
           getquestions();
           } ,
           ),
      ),
          ],
        ),
      ),
    );
  }
}


