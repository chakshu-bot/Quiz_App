import 'package:flutter/material.dart';


//import 'fifth.dart';
import 'main.dart';

//import 'second.dart';
//import 'third.dart';


class EndScreen extends StatefulWidget {
  const EndScreen({super.key});

  @override
  State<EndScreen> createState() => _EndScreenState();
}
//int index = 0;
//List storage_score = [];
class _EndScreenState extends State<EndScreen> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF483D8B),
        elevation: 0,
        title: Text('Congo! 🥳', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold), ),
      ),
      body: Container(
        decoration: BoxDecoration(
        gradient: RadialGradient(
          colors: [Color(0xFFE6E6FA), Color(0xFFFFDAD9), Color(0xFF98FB98),Color(0xFF87CEEB)],
          stops: [0.0,0.33,0.66,1.0],
        ),
      ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('You Have Done It 👍', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold,color: Color(0xFF2F4F4F),),),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        color: Color(0xFF87CEEB),
        elevation: 0,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Container(
              //   decoration: BoxDecoration(
              //     border: Border.all(width: 3),
              //     color: Color(0xFF483D8B),
              //   ),
              //   child: ElevatedButton(
              //     style: ButtonStyle(
              //       backgroundColor: MaterialStateProperty.all<Color>(Color(0xFF483D8B),), 
              //         ),
              //     child: Text(
              //       'Your Scores',
              //       style: TextStyle( fontWeight: FontWeight.bold ,fontSize: 20),
              //     ),
              //     onPressed:() {
              //      Navigator.push(
              //       context,
              //       MaterialPageRoute(
              //         builder: (context) => ScoreScreen(storageScore: storage_score),
              //       ),
              //       );
              //     }
              //     )
              //   ),
              FloatingActionButton(
                backgroundColor: Color(0xFF483D8B),
                child: Icon(Icons.home),
                onPressed: () {
                  setState(() {
                    //storage_score.add('Score of Test ${index+1}: $points/$number_of_questions');
                    //index++;
                   // points = 0;
                  });
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => StartScreen()),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}