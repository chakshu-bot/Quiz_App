import 'package:flutter/material.dart';
import 'package:flutter_app/second.dart';

void main() {
  runApp(Home());
}

class Home extends StatelessWidget {
  const Home({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: StartScreen(),
    );
  }
}

class StartScreen extends StatefulWidget {
  const StartScreen({super.key});

  @override
  State<StartScreen> createState() => _StartScreenState();
}

class _StartScreenState extends State<StartScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF483D8B),
        elevation: 0,
        title: Text(
          'CHALLENGE ACCEPTED!',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            colors: [Color(0xFFE6E6FA), Color(0xFFFFDAD9), Color(0xFF98FB98),Color(0xFF87CEEB)],
            stops: [0.0,0.33,0.66,1.0],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.only(top: 20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  'Test your knowledge by embarking on a journey of discovery! 💡',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF2F4F4F), 
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  'Click the start button to begin your adventure into a world of trivia and challenges. 🚀',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF2F4F4F), 
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: FloatingActionButton(
                  backgroundColor: Color(0xFF483D8B),
                    child: Icon(Icons.quiz),
                    onPressed: (){
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => QuizScreen()),
                      );
                    },
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  'Explore, learn, and have fun as you uncover fascinating facts and test your wits. 🔍',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF2F4F4F), 
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        color: Color(0xFF87CEEB),
        elevation: 0,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,// Due to this, on shortening the screen, it will overflow to right by 55 pixels(for 250 cross 480). if removed, there will be no overflow{written by me, not AI}
          children: [
            Text('Let the quest for knowledge begin! 🌟', 
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold,color: Color(0xFF2F4F4F),
            ),
            ),
          ],
        ),
      ),
    );
  }
}
