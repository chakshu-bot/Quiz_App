import 'package:flutter/material.dart';


import 'main.dart';

import 'second.dart';



class EndScreen extends StatefulWidget {
  const EndScreen({super.key});

  @override
  State<EndScreen> createState() => _EndScreenState();
}

class _EndScreenState extends State<EndScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF483D8B),
        elevation: 0,
        title: Text('Congo! 🥳', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold), ),
      ),
      body: Container(
        decoration: BoxDecoration(
        gradient: RadialGradient(
          colors: [Color(0xFFE6E6FA), Color(0xFFFFDAD9), Color(0xFF98FB98),Color(0xFF87CEEB)],
          stops: [0.0,0.33,0.66,1.0],
        ),
      ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('Your Score is: $points', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold,color: Color(0xFF2F4F4F),),),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        color: Color(0xFF87CEEB),
        elevation: 0,
        child: FloatingActionButton(
          backgroundColor: Color(0xFF483D8B),
          child: Icon(Icons.home),
          onPressed: (){
            points = 0;
            Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => StartScreen()),
            );
          }
          ),
        ),
    );
  }
}

 